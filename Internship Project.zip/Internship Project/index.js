/* SIP.html */

const express = require("express");
const path = require('path');
const bodyparser = require("body-parser");
const https = require("https");

const app = express();
app.use(bodyparser.urlencoded({extended:true}));

app.use(express.static('public'));

// Route for all HTML files
app.get("/:fileName", function(req, res) {
  const fileName = req.params.fileName;
  res.sendFile(path.join(__dirname, 'public', `${fileName}.html`));
});

app.get("/",function(req,res){
    res.sendFile(__dirname+"/SIP.html");
})

app.post("/",function(req,res){

    const stockName = req.body.stock;
    const s = req.body.size;
    const duration = req.body.timespan;
    const Fdate = req.body.fdate;
    const Tdate = req.body.tdate;
    const boo = req.body.boolean;
    const sor = req.body.sorting;
    const limi = req.body.limit;
    const appid = "mi1X4J_oOnXRX7YWMxiSAHDfTlnTRMMg";

    const url="https://api.polygon.io/v2/aggs/ticker/"+stockName+"/range/"+ s +"/"+duration+"/"+Fdate+"/"+Tdate+"?adjusted="+boo+"&sort="+sor+"&limit="+limi+"&apiKey="+appid;

    https.get(url,function(response){
        console.log(response.statusCode);

    response.on("data",function(data){
        const final = JSON.parse(data);
        const v = final.results[0].v;
        const vw = final.results[0].vw;
        const c = final.results[0].c
        const h = final.results[0].h
        const o = final.results[0].o;
        const l = final.results[0].l;
        const t = final.results[0].t;
        const n = final.results[0].n;
 
        res.write("<p> The trading volume of the symbol in the given time period:- "+v+"</p>");
        res.write("<p> The volume weighted average price:- "+vw+"</p>");
        res.write("<p> The open price for the symbol in the given time period:- "+o+"</p>");
        res.write("<p>The close price for the symbol in the given time period:-"+c+"</p>");
        res.write("<p>The highest price for the symbol in the given time period:-"+h+"</p>");
        res.write("<p> The lowest price for the symbol in the given time period:- "+l+"</p>");
        res.write("<p> The Unix Msec timestamp for the start of the aggregate window:- "+t+"</p>");
        res.write("<p> The number of transactions in the aggregate window:- "+n+"</p>");
        res.send();
    });
    });
});

app.listen(3001,()=>{
    console.log("Server is running");
})


