function calculateReturns() {
    const investmentAmount = parseFloat(document.getElementById("investmentAmount").value);
    const annualReturn = parseFloat(document.getElementById("annualReturn").value);
    const investmentDuration = parseFloat(document.getElementById("investmentDuration").value);
  
    const monthlyReturn = (1 + annualReturn / 100) ** (1 / 12) - 1;
    const totalInvestmentDuration = investmentDuration * 12;
  
    const maturityAmount =
      (investmentAmount * (1 + monthlyReturn) ** totalInvestmentDuration) +
      ((investmentAmount * monthlyReturn) *
        (((1 + monthlyReturn) ** totalInvestmentDuration - 1) / monthlyReturn));
  
    document.getElementById("maturityAmount").value = maturityAmount.toFixed(2);
  }
  