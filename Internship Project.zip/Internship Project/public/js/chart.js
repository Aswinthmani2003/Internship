new Chart(document.getElementById("pie-chart"),{
    type: 'pie',
    data:{
        lables:['Liquid','Equity'],
        datasets:[{
            backgroundColor:['red','blue'],
            data:[91,8]
        }]
    },
    options:{
        title:{
            display:true,
            text:'hello'
        },
        responsive:true
    }
});