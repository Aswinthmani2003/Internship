$("#sub1").on("click",function(){
    alert("Subscribed successfuly");
});

$("#ph1").on("click",function(){
    $("#ph1").text("9884408418").show();
});

$("#ph2").on("click",function(){
    $("#ph2").text("9884408418").show();
});
