function calculate() {
    var investmentAmount = document.getElementById("investmentAmount").value;
    var rateOfReturn = document.getElementById("rateOfReturn").value;
    var investmentDuration = document.getElementById("investmentDuration").value;

    var monthlyInvestmentAmount = investmentAmount / (investmentDuration * 12);
    var monthlyRateOfReturn = rateOfReturn / 1200;
    var maturityAmount = 0;

    for (var i = 0; i < investmentDuration * 12; i++) {
        maturityAmount = (maturityAmount + monthlyInvestmentAmount) * (1 + monthlyRateOfReturn);
    }

    document.getElementById("maturityAmount").value = maturityAmount.toFixed(2);
}
