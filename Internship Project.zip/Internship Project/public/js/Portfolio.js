function folio1(){
    window.open("folio1.html");
}

function folio2(){
    window.open("folio2.html");
}

function folio3(){
    window.open("folio3.html");
}

function folio4(){
    window.open("folio4.html");
}
