const express = require('express');
const bodyParser = require('body-parser');
const { MongoClient } = require('mongodb');
const crypto = require('crypto');

// Replace 'my-database' with your actual database name
const dbName = 'my-database';
const url = 'mongodb://127.0.0.1:27017';

const app = express();
const port = 3000;

app.use(express.static('public'));

// Middlewares
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public')); // Serve static files from 'public' directory

// MongoDB client
const client = new MongoClient(url, { useUnifiedTopology: true });

// Encryption key and IV for demonstration purposes
// In a real application, these should be securely generated and stored
const encryptionKey = crypto.randomBytes(32);
const iv = crypto.randomBytes(16);

// Helper functions for encryption and decryption
function encrypt(text, key, iv) {
  const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');
  return encrypted;
}

app.get('/', (req, res) => {
  res.redirect('/signup.html'); // Redirect root to signup page
});

app.get('/signup', (req, res) => {
  res.sendFile(__dirname + '/public/signup.html'); // Serve the signup form
});

app.post('/signup', async (req, res) => {
    const { username, password, email, phone_number } = req.body;
    const encryptedPassword = encrypt(password, encryptionKey, iv); // Encrypt password

    try {
        await client.connect();
        const db = client.db(dbName);
        const collection = db.collection('users');

        // Check if a user with the same username already exists
        const userExists = await collection.findOne({ username });

        if (userExists) {
            // If a user with the same username is found, send an alert message
            res.status(400).send('<script>alert("User already exists"); window.location="/signup.html";</script>');
        } else {
            // If no user exists, insert the new user into the database
            await collection.insertOne({
                username,
                password: encryptedPassword,
                email,
                phone_number
            });
            res.redirect('/login.html'); // Redirect to login page on success
        }
    } catch (err) {
        console.error('Error during signup:', err);
        res.status(500).send('Error during signup. Please try again.');
    } finally {
        await client.close();
    }
});


app.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const encryptedPassword = encrypt(password, encryptionKey, iv);
  
    try {
      await client.connect();
      const db = client.db(dbName);
      const collection = db.collection('users');
      
      // Find the user by username
      const user = await collection.findOne({ username });
  
      if (user && user.password === encryptedPassword) {
        // If the encrypted passwords match, redirect to invester.html
        res.redirect('/invester.html');
      } else {
        // If the passwords do not match, send an error message
        res.status(401).send('Invalid username or password.');
      }
    } catch (err) {
      console.error('Error during login:', err);
      res.status(500).send('An error occurred. Please try again.');
    } finally {
      await client.close();
    }
  });

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
